import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeodetailsComponent } from './geodetails.component';

describe('GeodetailsComponent', () => {
  let component: GeodetailsComponent;
  let fixture: ComponentFixture<GeodetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeodetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GeodetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
