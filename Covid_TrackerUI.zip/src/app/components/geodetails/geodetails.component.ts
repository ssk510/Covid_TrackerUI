import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-geodetails',
  templateUrl: './geodetails.component.html',
  styleUrls: ['./geodetails.component.scss']
})
export class GeodetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
