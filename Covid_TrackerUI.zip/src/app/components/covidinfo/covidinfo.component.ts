import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as _ from 'lodash';

@Component({
  selector: 'app-covidinfo',
  templateUrl: './covidinfo.component.html',
  styleUrls: ['./covidinfo.component.scss']
})
export class CovidinfoComponent implements OnInit {
  @ViewChild('addCovidInfo', { static: false, read: ModalDirective }) addCovidInfoModal: ModalDirective;
  // @ViewChild('companyPagination', { static: true, read: MdbTablePaginationComponent }) mdbTablePagination: MdbTablePaginationComponent;
  stockCmpSelect = new FormControl(null, Validators.required);
  addCovidInfoForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createFormsAndEvents();
  }

  private createFormsAndEvents() {
    this.addCovidInfoForm = this.fb.group({
      country: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      state: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      city: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isTested: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isConfirmed: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isQuarantine: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isRecovered: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isDeceased: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      dateTime: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) })
        });
  }

  get addCovidInfoFormControl() {
    return this.addCovidInfoForm.controls;
  }

  add() {
    this.addCovidInfoForm.reset();
    this.addCovidInfoModal.show();
  }

}
