import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as _ from 'lodash';

@Component({
  selector: 'app-geo-state',
  templateUrl: './geo-state.component.html',
  styleUrls: ['./geo-state.component.scss']
})
export class GeoStateComponent implements OnInit {
  @ViewChild('addState', { static: false, read: ModalDirective }) addStateModal: ModalDirective;
  // @ViewChild('companyPagination', { static: true, read: MdbTablePaginationComponent }) mdbTablePagination: MdbTablePaginationComponent;
  stockCmpSelect = new FormControl(null, Validators.required);
  addStateForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createFormsAndEvents();
  }

  private createFormsAndEvents() {
    this.addStateForm = this.fb.group({
      stateName: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(20)]), updateOn: 'blur' }),
      country: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) })
    });
  }

  get addStateFormControl() {
    return this.addStateForm.controls;
  }

  add() {
    this.addStateForm.reset();
    this.addStateModal.show();
  }


}
