import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeoStateComponent } from './geo-state.component';

describe('GeoStateComponent', () => {
  let component: GeoStateComponent;
  let fixture: ComponentFixture<GeoStateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeoStateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GeoStateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
