import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import * as moment from 'moment';
import * as _ from 'lodash';
import { combineLatest, of } from 'rxjs';
import { debounceTime, switchMap } from 'rxjs/operators';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormvalidationService } from 'src/app/services/validators.service';
import { IConfirmBoxPublicResponse } from '@costlydeveloper/ngx-awesome-popup';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.scss']
})
export class UserdetailsComponent implements OnInit {
  @ViewChild('addUsers', { static: false, read: ModalDirective }) addUserModal: ModalDirective;
  // @ViewChild('companyPagination', { static: true, read: MdbTablePaginationComponent }) mdbTablePagination: MdbTablePaginationComponent;
  stockCmpSelect = new FormControl(null, Validators.required);
  addUserForm: FormGroup;

  constructor(private fb: FormBuilder) { 
   
  }

  ngOnInit(): void {
    this.createFormsAndEvents();
  }

  private createFormsAndEvents() {
    this.addUserForm = this.fb.group({
      userFName: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(20)]), updateOn: 'blur' }),
      userLName: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      userEmail: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      userPhoneNo: new FormControl(null, { validators: Validators.compose([Validators.required]) }),
      userRole: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) })
    });
  }

  get addUserFormControl() {
    return this.addUserForm.controls;
  }

  add() {
    this.addUserForm.reset();
    this.addUserModal.show();
  }

}
