import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as _ from 'lodash';

@Component({
  selector: 'app-geo-city',
  templateUrl: './geo-city.component.html',
  styleUrls: ['./geo-city.component.scss']
})
export class GeoCityComponent implements OnInit {
  @ViewChild('addCity', { static: false, read: ModalDirective }) addCityModal: ModalDirective;
  // @ViewChild('companyPagination', { static: true, read: MdbTablePaginationComponent }) mdbTablePagination: MdbTablePaginationComponent;
  stockCmpSelect = new FormControl(null, Validators.required);
  addCityForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createFormsAndEvents();
  }

  private createFormsAndEvents() {
    this.addCityForm = this.fb.group({
      cityName: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(20)]), updateOn: 'blur' }),
      state: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      country: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) })
        });
  }

  get addCityFormControl() {
    return this.addCityForm.controls;
  }

  add() {
    this.addCityForm.reset();
    this.addCityModal.show();
  }

}
