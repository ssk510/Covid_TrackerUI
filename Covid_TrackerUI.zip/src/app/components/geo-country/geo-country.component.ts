import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as _ from 'lodash';

@Component({
  selector: 'app-geo-country',
  templateUrl: './geo-country.component.html',
  styleUrls: ['./geo-country.component.scss']
})
export class GeoCountryComponent implements OnInit {
  @ViewChild('addCountry', { static: false, read: ModalDirective }) addCountryModal: ModalDirective;
  // @ViewChild('companyPagination', { static: true, read: MdbTablePaginationComponent }) mdbTablePagination: MdbTablePaginationComponent;
  stockCmpSelect = new FormControl(null, Validators.required);
  addCountryForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createFormsAndEvents();
  }
  private createFormsAndEvents() {
    this.addCountryForm = this.fb.group({
      countryName: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(20)]), updateOn: 'blur' })
    });
  }

  get addCountryFormControl() {
    return this.addCountryForm.controls;
  }

  add() {
    this.addCountryForm.reset();
    this.addCountryModal.show();
  }
  
  onSubmit() {

    if (this.addCountryForm.valid) {

      
    }
  }

}
