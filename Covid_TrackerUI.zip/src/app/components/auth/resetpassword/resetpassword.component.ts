import { Component,OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SignIn } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.scss']
})
export class ResetpasswordComponent implements OnInit {
  resetForm: FormGroup;

  constructor(private fb: FormBuilder,
    private authService: AuthService, private router: Router) { 

      this.resetForm = this.fb.group({
        'UserName': ['', Validators.compose([Validators.required, Validators.email])],
        'UserPassword': ['', Validators.required]
      });
    }   

  ngOnInit(): void {
  }

  onSubmit() {
    const val = this.resetForm.value;
    const user: SignIn = {
      email: val.UserName,
      password: val.UserPassword
    };   
  }

}
