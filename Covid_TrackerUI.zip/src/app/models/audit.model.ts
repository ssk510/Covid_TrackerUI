export interface AuditFields {
    CreatedBy?: string,
    CreatedDate?: Date,
    ModifiedBy?: string,
    ModifiedDate?: Date
}