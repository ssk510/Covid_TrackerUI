export interface Country {
    Name: string;
    IsActive: boolean;
}

export interface State {
    Name: string;
    CountryId: number;
    IsActive: boolean;
}


export interface City {
    Name: string;
    CountryId: number;
    StateId: number;
    IsActive: boolean;
}