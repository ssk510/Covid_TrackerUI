import { Component, OnInit, ViewChild } from '@angular/core';
import { NavigationStart, Router, RouterEvent } from '@angular/router';
import { ModalDirective } from 'angular-bootstrap-md';
import { Auth } from 'aws-amplify';
import { from, interval } from 'rxjs';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public loggerUser: any = null;
  public isUserLoggedIn: boolean = false;
  public expireSeconds: number = 120000 / 1000;
  @ViewChild('sessionExpiryModal', { static: false, read: ModalDirective }) sessionExpiryModal: ModalDirective;

  constructor(private authService: AuthService,
    private router: Router) {

    
  }

  ngOnInit() {
   
  }

  continue(event: Event) {
   
  }

  signout(event: Event) {
    if (event)
      event.preventDefault();
    this.authService.signOut().then((res: boolean) => {
      if (res) {
        this.loggerUser = null;
        this.router.navigate(['signin']);
      }
    });
  }
}
