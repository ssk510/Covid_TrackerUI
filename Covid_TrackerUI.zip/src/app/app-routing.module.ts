import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SigninComponent } from './components/auth/signin/signin.component';
import { SignupComponent } from './components/auth/signup/signup.component';
import { CovidinfoComponent } from './components/covidinfo/covidinfo.component';
import { GeodetailsComponent } from './components/geodetails/geodetails.component';
import { HomeComponent } from './components/home/home.component';
import { UnAuthorizedComponent } from './components/un-authorized/un-authorized.component';
import { UserdetailsComponent } from './components/userdetails/userdetails.component';
import { GeoCountryComponent } from './components/geo-country/geo-country.component';
import { GeoStateComponent } from './components/geo-state/geo-state.component';
import { GeoCityComponent } from './components/geo-city/geo-city.component';
import { ResetpasswordComponent } from './components/auth/resetpassword/resetpassword.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'home' },
  {
    path: 'home',
    component: HomeComponent
   // canActivate: [AuthActivateGuardService]
  },
  {
    path: 'signin',
    component: SigninComponent
  },
  {
    path: 'signup',
    component: SignupComponent
  },
  {
    path: 'user-details',
    component: UserdetailsComponent
  },
  {
    path: 'geo-details',
    component: GeodetailsComponent
  },
  {
    path: 'geo-country',
    component: GeoCountryComponent
  },
  {
    path: 'geo-state',
    component: GeoStateComponent
  },
  {
    path: 'geo-city',
    component: GeoCityComponent
  },
  {
    path: 'covid-info',
    component: CovidinfoComponent
  },
  {
    path: 'un-authorized',
    component: UnAuthorizedComponent
  },
  {
    path: 'reset-pwd',
    component: ResetpasswordComponent
  },
  { path: '**', redirectTo: 'home' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
